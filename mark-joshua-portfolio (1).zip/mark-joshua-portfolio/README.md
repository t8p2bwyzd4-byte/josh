# Mark Joshua D. Gamboa — Personal Portfolio

A responsive, futuristic dark purple-blue portfolio built with **HTML5, CSS3, and vanilla JavaScript**. No build step, backend, or database is required.

## Project contents

```text
mark-joshua-portfolio/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    └── profile.jpg
```

## 1. Open the website locally

1. Download `mark-joshua-portfolio.zip`.
2. **Windows:** right-click the ZIP file and choose **Extract All…**. Open the extracted `mark-joshua-portfolio` folder.
3. **Phone:** open the ZIP using your Files app or a trusted archive app, then extract it to a folder.
4. Open `index.html` in a modern browser. The site is static, so no server or installation is required.
5. Keep `index.html`, `style.css`, `script.js`, and the `assets` folder together. The profile image path is `assets/profile.jpg`.

Google Fonts are loaded online; if offline, the site uses fallback fonts.

## 2. Personalize before publishing

Open `index.html` in a text editor and search for the clearly labeled contact placeholders. Replace them with your actual email address and GitHub profile URL when you are ready. Do not publish contact details you do not want public.

The three project cards are **sample projects / editable placeholders**, not claims that these projects have been completed. Update the descriptions, technologies, and links to reflect your actual work. For a real project link, change the relevant `href="#contact"` on its project link to your project URL.

You can change colors, spacing, and visual effects in `style.css`. The footer year updates automatically using `script.js`.

## 3. Upload to GitHub (beginner-friendly)

1. Sign in or create an account at [GitHub](https://github.com/).
2. Select **New repository** and give it a name such as `mark-joshua-portfolio`. Choose Public or Private as you prefer, then create the repository.
3. Open the repository page and choose **Add file → Upload files**.
4. Open the extracted project folder on your computer and upload **the contents of the folder**. Make sure `index.html`, `style.css`, `script.js`, `README.md`, and the `assets` folder (including `profile.jpg`) are included. Do not upload only the ZIP.
5. Add a commit message such as `Add personal portfolio website`, then click **Commit changes**.
6. Check the repository page and confirm that `index.html` is at the repository root and `assets/profile.jpg` exists.

## 4. Deploy using Vercel

1. Go to [Vercel](https://vercel.com/) and sign in. You can sign in with GitHub.
2. From the Vercel dashboard, choose **Add New → Project** (the wording may vary).
3. Import your `mark-joshua-portfolio` GitHub repository and authorize access if asked.
4. This is a static HTML project. You do not need a framework or build command. If asked, select **Other** as the framework preset and leave the build command empty. The output directory can be left as the default/root (`.`) for this project.
5. Click **Deploy** and wait for the deployment to finish.
6. Vercel will show a live URL, usually ending in `vercel.app`. Open it to check the site on desktop and mobile.
7. Later, push or commit changes to GitHub; Vercel can automatically redeploy the site.

Official guides: [GitHub — Adding a file to a repository](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository) · [Vercel — Deploying Git repositories](https://vercel.com/docs/deployments/git).

## 5. Troubleshooting

- **Photo missing:** make sure the image is named exactly `profile.jpg` and is inside `assets/`, next to the `index.html` file at the project root.
- **Styles missing:** check that `style.css` is beside `index.html`, and that the link in the HTML is `href="style.css"`.
- **Menu or year not working:** check that `script.js` is beside `index.html` and the script tag is present.
- **Changes not visible online:** commit the changed files to GitHub and check the latest deployment in Vercel.
- **Contact details:** the contact section is intentionally a placeholder display, not a message-sending form. Add real contact links before publishing.

## Privacy note

The profile photo you supplied is included as `assets/profile.jpg`. The site does not send form submissions or store visitor data.
